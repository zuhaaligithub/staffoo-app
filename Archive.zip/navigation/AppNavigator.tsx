// // AppNavigator.tsx
// import React, { useState, useEffect } from "react";
// import { createNativeStackNavigator } from "@react-navigation/native-stack";
// import AsyncStorage from "@react-native-async-storage/async-storage";

// // Screens
// import OnboardingScreen from "../screens/OnboardingScreen";
// import LoginScreen from "../screens/LoginScreen";
// import SignUpScreen from "../screens/SignUpScreen";
// import ForgotPasswordScreen from "../screens/ForgotPasswordScreen";
// import SplashScreen from "../screens/SplashScreen";
// // import MainDrawer from '../screens/MainDrawer';
// import FilterScreen from "../screens/FilterScreen";
// import ProfileSetupScreen from "../screens/ProfileSetupScreen";

// import NotificationScreen from "../screens/NotificationScreen";
// import ProfileScreen from "../screens/ProfileScreen";
// import JobDetailScreen from "../screens/JobDetailScreen";
// import AllJobsScreen from "../screens/AllJobsScreen";
// import ApplicationsScreen from "../screens/ApplicationsScreen";
// import ViewApplicationScreen from "../screens/ViewApplicationScreen";
// import MessageScreen from "../screens/MessageScreen";
// import MessageDetailScreen from "../screens/MessageDetailScreen";
// import ApplyJobScreen from "../screens/ApplyJobScreen";
// import SuccessScreen from "../screens/SuccessScreen";
// import DocumentsScreen from "../screens/DocumentsScreen";
// import AccountsScreen from "../screens/AccountsScreen";
// // import ChargeRatesScreen from '../screens/ChargeRatesScreen';
// // import PayRatesScreen from '../screens/PayRatesScreen';
// import CreateJobScreen from "../screens/CreateJobScreen";
// import ReviewConfirmScreen from "../screens/ReviewConfirmScreen";
// import StaffShifts from "../screens/StaffShifts";
// import SignInDetails from "../screens/SignInDetails";
// import OngoingShift from "../screens/OngoingShift";
// import CreateIncidentReport from "../screens/CreateIncidentReport";
// import CreateFootPatrol from "../screens/CreateFootPatrol";
// import AsapJobDetails from "../screens/AsapJobDetails";
// import PaymentHistoryScreen from "../screens/PaymentHistoryScreen";
// import PaymentMethodsScreen from "../screens/PaymentMethodsScreen";
// import LeaveManagementScreen from "../screens/LeaveManagementScreen";
// import HomeScreen from "../screens/HomeScreen";
// import PayslipScreen from "../screens/PayslipScreen";
// import JobPaymentHistory from "../screens/JobPaymentHistory";
// import StaffInduction from "../screens/StaffInduction";
// import InductionQuestionsScreen from "../screens/InductionQuestionScreen";
// import StaffFormsScreen from "../screens/StaffFormsScreen";
// import TestScreen from "../screens/TestScreen";
// import StaffManagement from "../screens/StaffManagement";
// import PoliciesScreen from "../screens/PoliciesScreen";
// import DeleteProfileVerification from "../screens/DeleteProfileVerification";
// import CoverJobsScreen from "../screens/CoverJobsScreen";
// import MainTabs from "../screens/MainTabs";

// // import InductionQuestionScreen from '../screens/InductionQuestionScreen';

// // ─── Define route params ────────────────────────────────────────────────
// export type RootStackParamList = {
//   Onboarding: undefined;
//   Login: undefined;
//   SignUp: undefined;
//   ForgotPassword: undefined;
//   Policies: undefined;
//   Filter: undefined;
//   ProfileSetup: undefined;
//   LeaveManagement: undefined;
//   Notifications: undefined;

//   JobDetails: { jobId?: string };
//   AllJobs: undefined;
//   Applications: undefined;
//   ViewApplications: undefined;
//   Messages: undefined;
//   MessageDetail: undefined;
//   Profile: undefined;
//   ApplyJob: undefined;
//   Documents: undefined;
//   Payslip: undefined;
//   Test: undefined;
//   Accounts: undefined;
//   MainTabs: undefined;
//   ChargeRates: undefined;
//   PayRates: undefined;
//   CreateJob: undefined;
//   Home: undefined;
//   ReviewConfirm: {
//     jobData: {
//       category: string;
//       guardsCount: number;
//       location: string;
//       lat: number;
//       lng: number;
//       description: string;
//       startDate: Date;
//       startTime: Date;
//       endDate: Date;
//       endTime: Date;
//     };
//     uploadedFilesCount: number;
//     selectedDocuments?: string[];
//     uploadedFileUrls?: string[];
//   };
//   DeleteProfileVerification: undefined;
//   Success: undefined;
//   StaffShifts: undefined;
//   StaffManagement: undefined;
//   SignIn: undefined;
//   Ongoing: undefined;
//   CreateIncidentReport: undefined;
//   CreateFootReport: undefined;
//   AsapJobDetails: undefined;
//   BreakForm: undefined;
//   PaymentHistory: undefined;
//   PaymentMethod: undefined;
//   JobPayment: undefined;
//   Induction: undefined;
//   StaffForms: undefined;
//   InductionQuestions: undefined;
//   CoverJobs: undefined;
//   Main: undefined;
// };

// const Stack = createNativeStackNavigator<RootStackParamList>();

// export default function AppNavigator() {
//   const [isLoading, setIsLoading] = useState(true);
//   const [initialRoute, setInitialRoute] = useState<
//     keyof RootStackParamList | null
//   >(null);

//   useEffect(() => {
//     const bootstrapAsync = async () => {
//       try {
//         const [hasSeenOnboarding, authToken, userStr] = await Promise.all([
//           AsyncStorage.getItem("hasSeenOnboarding"),
//           AsyncStorage.getItem("@auth_token"),
//           AsyncStorage.getItem("@user"),
//         ]);

//         console.log("[BOOTSTRAP] hasSeenOnboarding:", hasSeenOnboarding);
//         console.log("[BOOTSTRAP] authToken exists:", !!authToken);
//         console.log("[BOOTSTRAP] user exists:", !!userStr);

//         if (authToken) {
//           console.log("User is logged in → going to Main");
//           setInitialRoute("Profile");
//         } else if (hasSeenOnboarding === "true") {
//           console.log("Seen onboarding → going to Login");
//           setInitialRoute("Login");
//         } else {
//           console.log("First time → going to Onboarding");
//           setInitialRoute("Onboarding");
//         }
//       } catch (e) {
//         console.error("[BOOTSTRAP ERROR]", e);
//         setInitialRoute("Onboarding");
//       } finally {
//         setIsLoading(false);
//       }
//     };

//     bootstrapAsync();
//   }, []);

//   if (isLoading || !initialRoute) {
//     return <SplashScreen />;
//   }

//   return (
//     <Stack.Navigator
//       initialRouteName={initialRoute!}
//       screenOptions={{ headerShown: false, animation: "slide_from_right" }}
//     >
//       <Stack.Screen name="Onboarding" component={OnboardingScreen} />
//       <Stack.Screen name="Login" component={LoginScreen} />
//       <Stack.Screen name="SignUp" component={SignUpScreen} />
//       <Stack.Screen name="ForgotPassword" component={ForgotPasswordScreen} />
//       <Stack.Screen name="Filter" component={FilterScreen} />
//       <Stack.Screen name="ProfileSetup" component={ProfileSetupScreen} />
//       <Stack.Screen name="LeaveManagement" component={LeaveManagementScreen} />
//       <Stack.Screen name="Notifications" component={NotificationScreen} />
//       <Stack.Screen name="JobDetails" component={JobDetailScreen} />
//       <Stack.Screen name="AllJobs" component={AllJobsScreen} />
//       <Stack.Screen name="Applications" component={ApplicationsScreen} />
//       <Stack.Screen name="ViewApplications" component={ViewApplicationScreen} />
//       <Stack.Screen name="Messages" component={MessageScreen} />
//       <Stack.Screen name="Home" component={HomeScreen} />
//       <Stack.Screen name="MessageDetail" component={MessageDetailScreen} />
//       <Stack.Screen name="Profile" component={ProfileScreen} />
//       <Stack.Screen name="ApplyJob" component={ApplyJobScreen} />
//       <Stack.Screen name="Documents" component={DocumentsScreen} />
//       <Stack.Screen name="Payslip" component={PayslipScreen} />
//       <Stack.Screen name="Accounts" component={AccountsScreen} />
//       {/* <Stack.Screen name="ChargeRates" component={ChargeRatesScreen} /> */}
//       {/* <Stack.Screen name="PayRates" component={PayRatesScreen} /> */}
//       <Stack.Screen name="CreateJob" component={CreateJobScreen} />
//       <Stack.Screen name="ReviewConfirm" component={ReviewConfirmScreen} />
//       <Stack.Screen name="StaffShifts" component={StaffShifts} />
//       <Stack.Screen name="SignIn" component={SignInDetails} />
//       <Stack.Screen name="Ongoing" component={OngoingShift} />
//       <Stack.Screen
//         name="CreateIncidentReport"
//         component={CreateIncidentReport}
//       />
//       <Stack.Screen name="CreateFootReport" component={CreateFootPatrol} />
//       <Stack.Screen name="AsapJobDetails" component={AsapJobDetails} />
//       <Stack.Screen name="PaymentHistory" component={PaymentHistoryScreen} />
//       <Stack.Screen name="PaymentMethod" component={PaymentMethodsScreen} />
//       <Stack.Screen name="JobPayment" component={JobPaymentHistory} />
//       <Stack.Screen name="Induction" component={StaffInduction} />
//       <Stack.Screen name="StaffForms" component={StaffFormsScreen} />
//       <Stack.Screen name="Policies" component={PoliciesScreen} />
//       <Stack.Screen name="Test" component={TestScreen} />
//       <Stack.Screen name="StaffManagement" component={StaffManagement} />
//       <Stack.Screen name="CoverJobs" component={CoverJobsScreen} />
//       <Stack.Screen name="MainTabs" component={MainTabs} />
//       <Stack.Screen
//         name="DeleteProfileVerification"
//         component={DeleteProfileVerification}
//       />
//       <Stack.Screen
//         name="InductionQuestions"
//         component={InductionQuestionsScreen}
//         options={{
//           headerShown: false,
//           gestureEnabled: true,
//         }}
//       />
//       {/* <Stack.Screen name="Success" component={SuccessScreen} /> */}
//       {/* <Stack.Screen
//         name="Main"
//         component={MainDrawer}
//         options={{ gestureEnabled: false }}
//       /> */}
//     </Stack.Navigator>
//   );
// }

// AppNavigator.tsx
import React, { useState, useEffect } from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import AsyncStorage from "@react-native-async-storage/async-storage";

// Auth / Onboarding screens
import OnboardingScreen from "../screens/OnboardingScreen";
import LoginScreen from "../screens/LoginScreen";
import SignUpScreen from "../screens/SignUpScreen";
import ForgotPasswordScreen from "../screens/ForgotPasswordScreen";
import SplashScreen from "../screens/SplashScreen";

// Stack-only screens (no bottom tab needed or pushed on top of tabs)
import FilterScreen from "../screens/FilterScreen";
import ProfileSetupScreen from "../screens/ProfileSetupScreen";
import NotificationScreen from "../screens/NotificationScreen";
import JobDetailScreen from "../screens/JobDetailScreen";
import AllJobsScreen from "../screens/AllJobsScreen";
import ViewApplicationScreen from "../screens/ViewApplicationScreen";
import MessageDetailScreen from "../screens/MessageDetailScreen";
import ApplyJobScreen from "../screens/ApplyJobScreen";
import SuccessScreen from "../screens/SuccessScreen";
import DocumentsScreen from "../screens/DocumentsScreen";
import AccountsScreen from "../screens/AccountsScreen";
import CreateJobScreen from "../screens/CreateJobScreen";
import ReviewConfirmScreen from "../screens/ReviewConfirmScreen";
import SignInDetails from "../screens/SignInDetails";
import OngoingShift from "../screens/OngoingShift";
import CreateIncidentReport from "../screens/CreateIncidentReport";
import CreateFootPatrol from "../screens/CreateFootPatrol";
import AsapJobDetails from "../screens/AsapJobDetails";
import PaymentHistoryScreen from "../screens/PaymentHistoryScreen";
import PaymentMethodsScreen from "../screens/PaymentMethodsScreen";
import LeaveManagementScreen from "../screens/LeaveManagementScreen";
import PayslipScreen from "../screens/PayslipScreen";
import JobPaymentHistory from "../screens/JobPaymentHistory";
import StaffInduction from "../screens/StaffInduction";
import InductionQuestionsScreen from "../screens/InductionQuestionScreen";
import StaffFormsScreen from "../screens/StaffFormsScreen";
import TestScreen from "../screens/TestScreen";
import StaffManagement from "../screens/StaffManagement";
import PoliciesScreen from "../screens/PoliciesScreen";
import DeleteProfileVerification from "../screens/DeleteProfileVerification";
import CoverJobsScreen from "../screens/CoverJobsScreen";

// ── MainTabs: the persistent bottom-tab layout ──────────────────────────────
import MainTabs from "../screens/MainTabs";

// ─── Route param types ───────────────────────────────────────────────────────
export type RootStackParamList = {
  // Auth flow
  Onboarding: undefined;
  Login: undefined;
  SignUp: undefined;
  ForgotPassword: undefined;

  // ✅ Single entry point for all tabbed screens
  MainTabs: undefined;

  // Stack screens pushed on top of tabs
  Policies: undefined;
  Filter: undefined;
  ProfileSetup: undefined;
  LeaveManagement: undefined;
  Notifications: undefined;
  JobDetails: { jobId?: string };
  AllJobs: undefined;
  ViewApplications: undefined;
  MessageDetail: undefined;
  ApplyJob: undefined;
  Documents: undefined;
  Payslip: undefined;
  Test: undefined;
  Accounts: undefined;
  ReviewConfirm: {
    jobData: {
      category: string;
      guardsCount: number;
      location: string;
      lat: number;
      lng: number;
      description: string;
      startDate: Date;
      startTime: Date;
      endDate: Date;
      endTime: Date;
    };
    uploadedFilesCount: number;
    selectedDocuments?: string[];
    uploadedFileUrls?: string[];
  };
  DeleteProfileVerification: undefined;
  Success: undefined;
  StaffManagement: undefined;
  SignIn: undefined;
  Ongoing: undefined;
  CreateIncidentReport: undefined;
  CreateFootReport: undefined;
  AsapJobDetails: undefined;
  PaymentHistory: undefined;
  PaymentMethod: undefined;
  JobPayment: undefined;
  Induction: undefined;
  StaffForms: undefined;
  InductionQuestions: undefined;
  CoverJobs: undefined;
  CreateJob: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function AppNavigator() {
  const [isLoading, setIsLoading] = useState(true);
  const [initialRoute, setInitialRoute] = useState<
    keyof RootStackParamList | null
  >(null);

  useEffect(() => {
    const bootstrapAsync = async () => {
      try {
        const [hasSeenOnboarding, authToken] = await Promise.all([
          AsyncStorage.getItem("hasSeenOnboarding"),
          AsyncStorage.getItem("@auth_token"),
        ]);

        if (authToken) {
          // Authenticated → go straight into the tabbed layout
          setInitialRoute("MainTabs");
        } else if (hasSeenOnboarding === "true") {
          setInitialRoute("Login");
        } else {
          setInitialRoute("Onboarding");
        }
      } catch (e) {
        console.error("[BOOTSTRAP ERROR]", e);
        setInitialRoute("Onboarding");
      } finally {
        setIsLoading(false);
      }
    };

    bootstrapAsync();
  }, []);

  if (isLoading || !initialRoute) {
    return <SplashScreen />;
  }

  return (
    <Stack.Navigator
      initialRouteName={initialRoute!}
      screenOptions={{ headerShown: false, animation: "slide_from_right" }}
    >
      {/* ── Auth ── */}
      <Stack.Screen name="Onboarding" component={OnboardingScreen} />
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="SignUp" component={SignUpScreen} />
      <Stack.Screen name="ForgotPassword" component={ForgotPasswordScreen} />

      {/* ✅ Tabbed layout — bottom bar lives here permanently */}
      <Stack.Screen
        name="MainTabs"
        component={MainTabs}
        options={{ animation: "none" }} // no slide animation into tabs
      />

      {/* ── Stack screens pushed on top of tabs ── */}
      <Stack.Screen name="Filter" component={FilterScreen} />
      <Stack.Screen name="ProfileSetup" component={ProfileSetupScreen} />
      <Stack.Screen name="LeaveManagement" component={LeaveManagementScreen} />
      <Stack.Screen name="Notifications" component={NotificationScreen} />
      <Stack.Screen name="JobDetails" component={JobDetailScreen} />
      <Stack.Screen name="AllJobs" component={AllJobsScreen} />
      <Stack.Screen name="ViewApplications" component={ViewApplicationScreen} />
      <Stack.Screen name="MessageDetail" component={MessageDetailScreen} />
      <Stack.Screen name="ApplyJob" component={ApplyJobScreen} />
      <Stack.Screen name="Documents" component={DocumentsScreen} />
      <Stack.Screen name="Payslip" component={PayslipScreen} />
      <Stack.Screen name="Accounts" component={AccountsScreen} />
      <Stack.Screen name="CreateJob" component={CreateJobScreen} />
      <Stack.Screen name="ReviewConfirm" component={ReviewConfirmScreen} />
      <Stack.Screen name="SignIn" component={SignInDetails} />
      <Stack.Screen name="Ongoing" component={OngoingShift} />
      <Stack.Screen
        name="CreateIncidentReport"
        component={CreateIncidentReport}
      />
      <Stack.Screen name="CreateFootReport" component={CreateFootPatrol} />
      <Stack.Screen name="AsapJobDetails" component={AsapJobDetails} />
      <Stack.Screen name="PaymentHistory" component={PaymentHistoryScreen} />
      <Stack.Screen name="PaymentMethod" component={PaymentMethodsScreen} />
      <Stack.Screen name="JobPayment" component={JobPaymentHistory} />
      <Stack.Screen name="Induction" component={StaffInduction} />
      <Stack.Screen name="StaffForms" component={StaffFormsScreen} />
      <Stack.Screen name="Policies" component={PoliciesScreen} />
      <Stack.Screen name="Test" component={TestScreen} />
      <Stack.Screen name="StaffManagement" component={StaffManagement} />
      <Stack.Screen name="CoverJobs" component={CoverJobsScreen} />
      <Stack.Screen
        name="DeleteProfileVerification"
        component={DeleteProfileVerification}
      />
      <Stack.Screen
        name="InductionQuestions"
        component={InductionQuestionsScreen}
        options={{ headerShown: false, gestureEnabled: true }}
      />
    </Stack.Navigator>
  );
}
