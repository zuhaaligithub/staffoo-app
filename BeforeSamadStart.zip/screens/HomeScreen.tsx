import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  FlatList,
  SafeAreaView,
  StatusBar,
  Dimensions,
  ImageSourcePropType,
  Platform,
  Linking,
  Alert,
  PermissionsAndroid,
  ActivityIndicator,
} from "react-native";
import Geolocation from "react-native-geolocation-service";
import BottomTab from "./BottomTab";
import AsyncStorage from "@react-native-async-storage/async-storage";
import axios from "axios";
import LinearGradient from "react-native-linear-gradient";
import { BASE_URL } from "../services/authApi";

const { width } = Dimensions.get("window");

const COLORS = {
  background: "#030508",
  surface: "#07111A",
  card: "#0D1421", // ← Used everywhere for cards
  cardBorder: "rgba(98, 97, 97, 0.83)",
  primary: "#00A99D",
  primaryGlow: "rgba(0,169,157,0.25)",
  primaryBorder: "rgba(0,169,157,0.25)",
  text: "#FFFFFF",
  textSecondary: "#94A3B8",
  textMuted: "#4A6080",
  success: "#34C88A",
  danger: "#F87171",
  heroBg1: "#0D1F2D",
  heroBg2: "#061014",
};

type Category = {
  id: string;
  title: string;
  icon: ImageSourcePropType;
};

const categories = [
  { id: "1", title: "Security License", icon: require("../assets/admin.png") },
  { id: "2", title: "MISC Time License", icon: require("../assets/it.png") },
  {
    id: "3",
    title: "Working With Children",
    icon: require("../assets/developer.png"),
  },
  { id: "4", title: "First Aid", icon: require("../assets/data-admin.png") },
  { id: "5", title: "CPR", icon: require("../assets/electrician.png") },
  {
    id: "6",
    title: "White Card",
    icon: require("../assets/development-web.png"),
  },
  {
    id: "7",
    title: "Traffic Controller",
    icon: require("../assets/business-management.png"),
  },
];

export default function HomeScreen({ navigation }: any) {
  const [sites, setSites] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const [userType, setUserType] = useState<"customer" | "contractor" | "staff">(
    "staff",
  );
  const [isActive, setIsActive] = useState<boolean>(false);
  const [profileImage, setProfileImage] = useState<string | null>(null);
  const [currentLocation, setCurrentLocation] = useState<{
    latitude: number;
    longitude: number;
  } | null>(null);

  const formatDateMMDDYYYY = (date: Date) =>
    `${(date.getMonth() + 1).toString().padStart(2, "0")}-${date
      .getDate()
      .toString()
      .padStart(2, "0")}-${date.getFullYear()}`;

  const currentDate = new Date();
  const [weekStart] = useState(() => {
    const d = new Date(currentDate);
    d.setDate(d.getDate() - d.getDay() + (d.getDay() === 0 ? -6 : 1));
    return d;
  });

  const capitalizeWords = (text: string = "") =>
    text.replace(/\b\w/g, (char) => char.toUpperCase());

  const calculateTotalHours = (jobRoster: any[]) => {
    if (!jobRoster || jobRoster.length === 0) return 0;
    return jobRoster.reduce((total, job) => {
      if (job.start && job.end) {
        const start = new Date(job.start);
        const end = new Date(job.end);
        const hours = (end.getTime() - start.getTime()) / (1000 * 60 * 60);
        return total + Math.max(0, hours);
      }
      return total;
    }, 0);
  };

  const fetchCustomerSites = async () => {
    setLoading(true);

    try {
      const token = await AsyncStorage.getItem("@auth_token");
      const userStr = await AsyncStorage.getItem("user");

      if (!token || !userStr) {
        setLoading(false);
        return;
      }

      const userData = JSON.parse(userStr);

      const start = formatDateMMDDYYYY(weekStart);
      const end = formatDateMMDDYYYY(
        new Date(weekStart.getTime() + 6 * 86400000),
      );

      const payload = {
        user_id: [userData.id],
        start,
        end,
        roster_id: "1",
        page: 1,
      };

      console.log("Job Details Payload:", payload);

      const res = await axios.post(`${BASE_URL}/job-details`, payload, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (res.data?.success) {
        setSites(res.data.data || []);
      }
    } catch (err) {
      console.log("Fetch sites error:", err);
    } finally {
      setLoading(false);
    }
  };

  const getInitials = (name: string): string => {
    if (!name) return "U";
    const nameParts = name.trim().split(" ").filter(Boolean);
    if (nameParts.length === 1) {
      return nameParts[0].charAt(0).toUpperCase();
    }
    return (
      nameParts[0].charAt(0).toUpperCase() +
      nameParts[nameParts.length - 1].charAt(0).toUpperCase()
    );
  };

  // Determine user type
  const determineUserType = (
    userData: any,
  ): "customer" | "contractor" | "staff" => {
    if (!userData) return "staff";

    // Adjust these conditions based on your actual user object structure
    if (
      userData.role === "customer" ||
      userData.user_type === "customer" ||
      userData.type === "customer"
    ) {
      return "customer";
    }
    if (
      userData.role === "contractor" ||
      userData.user_type === "contractor" ||
      userData.type === "contractor"
    ) {
      return "contractor";
    }
    // Default to staff (has staff profile)
    if (
      userData.staff ||
      userData.role === "staff" ||
      userData.user_type === "staff"
    ) {
      return "staff";
    }
    return "staff";
  };

  useEffect(() => {
    fetchCustomerSites();
  }, []);

  useEffect(() => {
    const loadProfileAndLocation = async () => {
      const storedUser = await AsyncStorage.getItem("user");
      const cachedImage = await AsyncStorage.getItem("profileImage");

      if (storedUser) {
        const parsedUser = JSON.parse(storedUser);
        setUser(parsedUser);
        setIsActive(parsedUser.is_active);

        // Set user type
        const type = determineUserType(parsedUser);
        setUserType(type);

        // Priority: Cached Image > API Data Image
        if (cachedImage) {
          setProfileImage(cachedImage);
        } else if (parsedUser?.staff?.profile_image) {
          // const BASE_IMAGE_URL = "https://apis.staffoo.com.au/storage/";
          const BASE_IMAGE_URL = "https://staging.apis.staffoo.com.au/storage/";
          setProfileImage(`${BASE_IMAGE_URL}${parsedUser.staff.profile_image}`);
        }
      }
    };
    loadProfileAndLocation();
  }, []);

  const capitalizeName = (name: string = "") => {
    return name
      .toLowerCase()
      .split(" ")
      .filter(Boolean)
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");
  };

  const sortedSites = [...sites].sort((siteA, siteB) => {
    const latestA = siteA.job_roster?.length
      ? Math.max(
          ...siteA.job_roster.map((j: any) => new Date(j.start).getTime()),
        )
      : 0;
    const latestB = siteB.job_roster?.length
      ? Math.max(
          ...siteB.job_roster.map((j: any) => new Date(j.start).getTime()),
        )
      : 0;
    return latestB - latestA;
  });

  const displayedSites = sortedSites.slice(0, 2);
  const hasMoreSites = sites.length > 2;

  // Dynamic banner content based on user type
  const getBannerContent = () => {
    switch (userType) {
      case "customer":
        return {
          title: "Post Jobs & Manage\nYour Workforce",
          infoTitle: "💼 Active Opportunities",
          infoSubtitle: "Post • Assign • Track",
        };
      case "contractor":
        return {
          title: "Manage Your Team &\nSchedule Shifts",
          infoTitle: "👷 Crew Management",
          infoSubtitle: "Assign • Monitor • Optimize",
        };
      case "staff":
      default:
        return {
          title: "Discover Your Next\nOpportunity",
          infoTitle: "💼 Jobs Available",
          infoSubtitle: "Full Time • Part Time • Contract",
        };
    }
  };

  const bannerContent = getBannerContent();
  if (loading) {
    return (
      <SafeAreaView
        style={{
          flex: 1,
          justifyContent: "center",
          alignItems: "center",
          backgroundColor: "#030508",
        }}
      >
        <ActivityIndicator size="large" color="#1E88E5" />
        <Text style={{ marginTop: 15, fontSize: 16, color: "#fff" }}>
          Loading profile...
        </Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#fff" />

      {/* Fixed Header */}
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.avatarBox}
          onPress={() => navigation.navigate("ProfileSetup")}
        >
          {profileImage ? (
            <Image source={{ uri: profileImage }} style={styles.avatar} />
          ) : (
            <View style={styles.initialsAvatar}>
              <Text style={styles.initialsText}>
                {getInitials(user?.name || "User")}
              </Text>
            </View>
          )}
          <View style={styles.welcomeContent}>
            <Text style={styles.welcomeText}>Welcome back!</Text>
            <View style={styles.nameRow}>
              <Text style={styles.name}>
                {capitalizeName(user?.name || "User Name")}
              </Text>
              <Image
                source={require("../assets/hello.png")}
                style={styles.helloIcon}
              />
            </View>
          </View>
        </TouchableOpacity>
      </View>
      <View style={{ flex: 1 }}>
        <View style={styles.fixedTopSection}>
          <LinearGradient
            colors={[COLORS.heroBg1, COLORS.heroBg2]}
            style={styles.banner}
          >
            <View style={styles.bannerContent}>
              <Text style={styles.bannerTitle}>{bannerContent.title}</Text>
              <View style={styles.infoBox}>
                <Text style={styles.infoText}>{bannerContent.infoTitle}</Text>
                <Text style={styles.infoSubText}>
                  {bannerContent.infoSubtitle}
                </Text>
              </View>
            </View>
            <Image
              source={require("../assets/banner-1.png")}
              style={styles.bannerImage}
            />
          </LinearGradient>

          {/* Browse By Category */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Browse By Category</Text>
            <FlatList
              data={categories}
              horizontal
              showsHorizontalScrollIndicator={false}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => (
                <LinearGradient
                  colors={[COLORS.heroBg1, COLORS.heroBg2]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={styles.categoryItem}
                >
                  <TouchableOpacity
                    activeOpacity={0.8}
                    style={{ alignItems: "center" }}
                  >
                    <Image source={item.icon} style={styles.categoryIcon} />
                    <Text style={styles.categoryTitle}>{item.title}</Text>
                  </TouchableOpacity>
                </LinearGradient>
              )}
              contentContainerStyle={styles.categoryList}
            />
          </View>
        </View>

        <View style={[styles.section, { flex: 1 }]}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Shifts This Week</Text>
            {sites.length > 0 && (
              <TouchableOpacity
                activeOpacity={0.7}
                onPress={() => navigation.navigate("Applications")}
              >
                <Text style={styles.seeAll}>See All</Text>
              </TouchableOpacity>
            )}
          </View>

          {/* Fixed Height Scrollable Container */}
          <View style={styles.shiftsWrapper}>
            <ScrollView
              nestedScrollEnabled={true}
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.shiftsScrollContent}
            >
              {sites.length === 0 ? (
                <Text style={styles.noShiftText}>
                  No shifts found this week.
                </Text>
              ) : (
                sites.map((job: any) => {
                  const status = job.job_status?.toLowerCase();

                  const shiftDate = job.start
                    ? new Date(job.start).toLocaleDateString("en-GB", {
                        day: "2-digit",
                        month: "short",
                        year: "numeric",
                      })
                    : "--";

                  const startTime =
                    job.start?.split(" ")[1]?.slice(0, 5) || "--:--";
                  const endTime =
                    job.end?.split(" ")[1]?.slice(0, 5) || "--:--";

                  return (
                    <LinearGradient
                      key={job.id}
                      colors={[COLORS.heroBg1, COLORS.heroBg2]}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 1, y: 1 }}
                      style={styles.siteCard}
                    >
                      <View style={styles.siteCardInner}>
                        {/* Same as before */}
                        <Text style={styles.siteName}>
                          {job.site?.site_name || "Unnamed Site"}
                        </Text>

                        <Text style={styles.siteAddress}>
                          {job.site?.address ||
                            job.guards?.address ||
                            "No address available"}
                        </Text>

                        <Text style={styles.totalHours}>
                          Total Hours: {job.hours || 0}
                        </Text>

                        <View style={styles.shiftRow}>
                          <View>
                            <Text style={styles.shiftDate}>{shiftDate}</Text>

                            <Text style={styles.shiftTime}>
                              {startTime} - {endTime}
                            </Text>
                          </View>

                          <Text style={styles.guardName}>
                            {job.guards?.name
                              ? capitalizeWords(job.guards.name)
                              : "Unassigned"}
                          </Text>

                          <View
                            style={[
                              styles.statusBadge,
                              status === "pending"
                                ? { backgroundColor: "#FEE2E2" }
                                : status === "confirmed"
                                ? { backgroundColor: "#FEF3C7" }
                                : status === "completed"
                                ? { backgroundColor: "#D1FAE5" }
                                : { backgroundColor: "#E5E7EB" },
                            ]}
                          >
                            <Text
                              style={[
                                styles.statusText,
                                {
                                  color:
                                    status === "pending"
                                      ? "#DC2626"
                                      : status === "confirmed"
                                      ? "#F59E0B"
                                      : status === "completed"
                                      ? "#16A34A"
                                      : "#374151",
                                },
                              ]}
                            >
                              {status || "pending"}
                            </Text>
                          </View>
                        </View>
                      </View>
                    </LinearGradient>
                  );
                })
              )}
            </ScrollView>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
    paddingTop: 25,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  infoBox: {
    marginTop: 16,
    backgroundColor: COLORS.surface,
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 12,
    alignSelf: "flex-start",
    marginBottom: 20,
    borderWidth: 1,
    borderColor: COLORS.cardBorder,
  },
  infoText: {
    fontSize: 14,
    fontWeight: "700",
    color: COLORS.text,
  },
  infoSubText: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  avatarBox: {
    flexDirection: "row",
    alignItems: "center",
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    borderWidth: 2,
    borderColor: COLORS.primary,
  },
  initialsAvatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: COLORS.surface,
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 1,
    borderColor: COLORS.primaryBorder,
  },
  siteCardInner: {
    padding: 12,
  },
  welcomeContent: {
    marginLeft: 12,
  },
  welcomeText: {
    fontSize: 13,
    color: COLORS.textSecondary,
  },
  nameRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  name: {
    fontSize: 18,
    fontWeight: "700",
    color: COLORS.text,
  },
  shiftDate: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginBottom: 2,
    fontWeight: "500",
  },
  helloIcon: {
    width: 20,
    height: 20,
    marginLeft: 6,
  },
  scrollContent: {
    flex: 1,
  },
  bannerContent: {
    flex: 1,
  },
  banner: {
    marginHorizontal: 15,
    borderRadius: 18,
    padding: 12,
    paddingRight: 20,
    flexDirection: "row",
    justifyContent: "space-between",
    backgroundColor: COLORS.card,
    alignItems: "center",
  },
  bannerTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: COLORS.text,
    lineHeight: 26,
  },
  bannerImage: {
    width: 130,
    height: 130,
    resizeMode: "contain",
  },
  section: {
    paddingHorizontal: 15,
    marginVertical: 10,
  },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "800",
    color: COLORS.text,
  },
  shiftsScrollContainer: {
    maxHeight: 400, // Adjust as needed
    paddingBottom: 10,
  },
  seeAll: {
    color: COLORS.primary,
    fontWeight: "600",
  },
  siteCard: {
    width: "100%",
    borderRadius: 14,
    marginBottom: 12,
    overflow: "hidden",
  },
  siteName: {
    fontSize: 16,
    fontWeight: "700",
    color: COLORS.text,
  },
  siteAddress: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginVertical: 6,
  },
  totalHours: {
    fontSize: 14,
    fontWeight: "700",
    color: COLORS.primary,
    marginBottom: 10,
  },
  initialsText: {
    color: COLORS.text,
    fontSize: 20,
    fontWeight: "700",
  },
  shiftRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 10,
    borderTopWidth: 1,
    borderTopColor: COLORS.cardBorder,
  },
  shiftTime: {
    fontSize: 13,
    color: COLORS.text,
    fontWeight: "500",
  },
  guardName: {
    fontSize: 13,
    color: COLORS.textSecondary,
  },
  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 6,
  },
  statusText: {
    fontSize: 11,
    fontWeight: "600",
    textTransform: "capitalize",
  },
  categoryItem: {
    backgroundColor: COLORS.card,
    width: 90,
    height: 78,
    borderRadius: 12,
    marginRight: 10,
    padding: 10,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: COLORS.cardBorder,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 2,
  },
  categoryList: {
    paddingVertical: 8,
  },
  categoryIcon: {
    width: 34,
    height: 34,
    tintColor: COLORS.primary,
    marginBottom: 6,
  },
  categoryTitle: {
    fontSize: 10,
    color: COLORS.text,
    textAlign: "center",
  },
  fixedTopSection: {
    backgroundColor: COLORS.background,
  },

  shiftsContainer: {
    flex: 1,
    backgroundColor: COLORS.background,
  },

  shiftsWrapper: {
    flex: 1, // Let it take up all available remaining space
    backgroundColor: COLORS.background,
    borderRadius: 12,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: COLORS.cardBorder,
    marginBottom: 20, // Add space for the bottom tab
  },

  shiftsScrollContent: {
    padding: 10,
    paddingBottom: 50,
  },

  noShiftText: {
    paddingVertical: 40,
    color: "#666",
    textAlign: "center",
    fontSize: 15,
  },
});
