// // import React, { useEffect, useRef, useState, useCallback } from "react";
// // import {
// //   StyleSheet,
// //   StatusBar,
// //   Platform,
// //   AppState,
// //   AppStateStatus,
// // } from "react-native";
// // import { GestureHandlerRootView } from "react-native-gesture-handler";
// // import {
// //   NavigationContainer,
// //   NavigationContainerRef,
// // } from "@react-navigation/native";
// // import Toast from "react-native-toast-message";
// // import { LogLevel, OneSignal } from "react-native-onesignal";
// // import AsyncStorage from "@react-native-async-storage/async-storage";
// // import { StripeProvider } from "@stripe/stripe-react-native";

// // import AppNavigator from "./navigation/AppNavigator";
// // import CallOverlay from "./screens/CallOverlay";
// // import { useEchoCallListener } from "./useCallManagerRN";
// // import SplashScreen from "./screens/SplashScreen"; // Import Splash Screen

// // const ONESIGNAL_APP_ID = "79041c59-5506-4e56-9de4-8a6619f85e1d";
// // const PENDING_ASAP_NOTIFICATION_KEY = "@pending_asap_notification";
// // const TARGET_ROUTE_NAME = "StaffShifts";
// // const MAIN_TABS_ROUTE_NAME = "MainTabs";

// // export let navigationRef: NavigationContainerRef<any> | null = null;

// // export default function App() {
// //   const STRIPE_PUBLISHABLE_KEY =
// //     "pk_test_51TBYBwDb535HMVUZHtQiPJGDYYZex0gIGvFWtuKR9FRage5WxqqzkLDvKBUpq4MfPkWhgDDM7z3WZrURpwWFBkbo005rxvV6q9";

// //   const [isSplashVisible, setIsSplashVisible] = useState(true);

// //   useEchoCallListener();

// //   const userTypeRef = useRef<string | null>(null);
// //   const clickHandlerRef = useRef<any>(null);
// //   const foregroundHandlerRef = useRef<any>(null);
// //   const flushInFlightRef = useRef(false);

// //   // Hide splash screen after some time
// //   useEffect(() => {
// //     const hideSplashTimer = setTimeout(() => {
// //       setIsSplashVisible(false);
// //     }, 2200); // Show splash for 2.2 seconds

// //     return () => clearTimeout(hideSplashTimer);
// //   }, []);

// //   // Load user type
// //   useEffect(() => {
// //     const loadUserTypeAndRequestPermission = async () => {
// //       try {
// //         const stored = await AsyncStorage.getItem("@user_type");
// //         userTypeRef.current = stored;
// //         if (stored === "staff" || stored === "contractor") {
// //           requestBackgroundLocationPermission();
// //         }
// //       } catch (err) {
// //         console.warn("Error loading user type:", err);
// //       }
// //     };
// //     loadUserTypeAndRequestPermission();
// //   }, []);

// //   const requestBackgroundLocationPermission = async () => {
// //     const userType = userTypeRef.current;
// //     if (!userType) return;
// //   };
// //   const flushPendingNotification = useCallback(async () => {
// //     if (flushInFlightRef.current) {
// //       console.log("⏳ flushPendingNotification already in progress");
// //       return;
// //     }

// //     flushInFlightRef.current = true;
// //     console.log("🔄 Starting flushPendingNotification...");

// //     try {
// //       const pending = await AsyncStorage.getItem(PENDING_ASAP_NOTIFICATION_KEY);
// //       console.log("📥 Pending from storage:", pending ? "FOUND" : "NOT FOUND");

// //       if (!pending) return;

// //       let notificationJob: any = null;
// //       try {
// //         notificationJob = JSON.parse(pending);
// //       } catch (e) {
// //         console.error("❌ Corrupt pending payload:", e);
// //         await AsyncStorage.removeItem(PENDING_ASAP_NOTIFICATION_KEY);
// //         return;
// //       }

// //       if (navigationRef?.isReady()) {
// //         console.log("🧭 Navigating to StaffShifts with notification");
// //         navigationRef.navigate(MAIN_TABS_ROUTE_NAME, {
// //           screen: TARGET_ROUTE_NAME,
// //           params: { notificationJob },
// //         });
// //         await AsyncStorage.removeItem(PENDING_ASAP_NOTIFICATION_KEY);
// //       } else {
// //         console.log("⚠️ Navigation ref not ready yet");
// //       }
// //     } catch (e) {
// //       console.error("❌ flushPendingNotification error:", e);
// //     } finally {
// //       flushInFlightRef.current = false;
// //     }
// //   }, []);
// //   // const flushPendingNotification = useCallback(async () => {
// //   //   if (flushInFlightRef.current) return;
// //   //   flushInFlightRef.current = true;
// //   //   try {
// //   //     const maxAttempts = 20;
// //   //     for (let attempt = 0; attempt < maxAttempts; attempt++) {
// //   //       const pending = await AsyncStorage.getItem(
// //   //         PENDING_ASAP_NOTIFICATION_KEY,
// //   //       );
// //   //       if (!pending) return;

// //   //       if (navigationRef?.isReady()) {
// //   //         let notificationJob: any = null;
// //   //         try {
// //   //           notificationJob = JSON.parse(pending);
// //   //         } catch (e) {
// //   //           console.log("[Notification] Corrupt pending payload, dropping", e);
// //   //           await AsyncStorage.removeItem(PENDING_ASAP_NOTIFICATION_KEY);
// //   //           return;
// //   //         }

// //   //         navigationRef.navigate(MAIN_TABS_ROUTE_NAME, {
// //   //           screen: TARGET_ROUTE_NAME,
// //   //           params: { notificationJob },
// //   //         });
// //   //         await new Promise((resolve) => setTimeout(resolve, 400));

// //   //         const current = navigationRef?.getCurrentRoute?.();
// //   //         const currentParams = current?.params as
// //   //           | { screen?: string }
// //   //           | undefined;
// //   //         const isOnStaffShifts =
// //   //           current?.name === TARGET_ROUTE_NAME ||
// //   //           (current?.name === MAIN_TABS_ROUTE_NAME &&
// //   //             currentParams?.screen === TARGET_ROUTE_NAME);

// //   //         if (isOnStaffShifts) {
// //   //           await AsyncStorage.removeItem(PENDING_ASAP_NOTIFICATION_KEY);
// //   //           return;
// //   //         }
// //   //       }
// //   //       await new Promise((resolve) => setTimeout(resolve, 500));
// //   //     }
// //   //     console.log(
// //   //       "[Notification] Gave up delivering pending notification after retries",
// //   //     );
// //   //   } catch (e) {
// //   //     console.log("[Notification] flushPendingNotification error:", e);
// //   //   } finally {
// //   //     flushInFlightRef.current = false;
// //   //   }
// //   // }, []);

// //   // OneSignal Setup
// //   useEffect(() => {
// //     const initOneSignal = async () => {
// //       OneSignal.Debug.setLogLevel(LogLevel.None);
// //       OneSignal.initialize(ONESIGNAL_APP_ID);
// //       OneSignal.Notifications.requestPermission(true);

// //       const handleClick = (event: any) => {
// //         const notif = event?.notification ?? null;
// //         if (notif) handleNotificationOpen(notif);
// //       };
// //       clickHandlerRef.current = handleClick;
// //       OneSignal.Notifications.addEventListener("click", handleClick);

// //       const handleForeground = (event: any) => {
// //         if (userTypeRef.current === "customer") {
// //           event.preventDefault();
// //           return;
// //         }
// //         const notif = event?.getNotification?.();
// //         notif?.display();
// //       };
// //       foregroundHandlerRef.current = handleForeground;
// //       OneSignal.Notifications.addEventListener(
// //         "foregroundWillDisplay",
// //         handleForeground,
// //       );
// //     };

// //     initOneSignal();

// //     return () => {
// //       if (clickHandlerRef.current) {
// //         OneSignal.Notifications.removeEventListener(
// //           "click",
// //           clickHandlerRef.current,
// //         );
// //       }
// //       if (foregroundHandlerRef.current) {
// //         OneSignal.Notifications.removeEventListener(
// //           "foregroundWillDisplay",
// //           foregroundHandlerRef.current,
// //         );
// //       }
// //     };
// //   }, []);

// //   // AppState listener + boot flush
// //   useEffect(() => {
// //     const sub = AppState.addEventListener("change", (state: AppStateStatus) => {
// //       if (state === "active") {
// //         flushPendingNotification();
// //       }
// //     });

// //     const bootTimer = setTimeout(() => {
// //       flushPendingNotification();
// //     }, 1000);

// //     return () => {
// //       sub.remove();
// //       clearTimeout(bootTimer);
// //     };
// //   }, [flushPendingNotification]);

// //   // const handleNotificationOpen = async (notification: any) => {
// //   //   if (!notification) return;
// //   //   if (userTypeRef.current === "customer") {
// //   //     console.log("[Notification] Ignored for customer");
// //   //     return;
// //   //   }

// //   //   const additionalData = notification?.additionalData ?? {};
// //   //   const pageName = additionalData?.page;
// //   //   if (pageName !== "asap-job-list") return;

// //   //   const rosterWrapper = additionalData?.roster ?? {};
// //   //   const rawRoster = rosterWrapper?.roster ?? {};
// //   //   if (!rawRoster?.id) return;

// //   //   const notificationJob = {
// //   //     additionalData: {
// //   //       roster: {
// //   //         roster: { ...rawRoster },
// //   //         distance: rosterWrapper.distance ?? null,
// //   //       },
// //   //     },
// //   //     roster: { roster: { ...rawRoster } },
// //   //     distance: rosterWrapper.distance ?? null,
// //   //   };

// //   //   try {
// //   //     await AsyncStorage.setItem(
// //   //       PENDING_ASAP_NOTIFICATION_KEY,
// //   //       JSON.stringify(notificationJob),
// //   //     );
// //   //   } catch (e) {
// //   //     console.log("[Notification] Failed to persist pending notification:", e);
// //   //     return;
// //   //   }

// //   //   flushPendingNotification();
// //   // };
// //   const handleNotificationOpen = async (notification: any) => {
// //     console.log(
// //       "🔴 [NOTIFICATION RECEIVED] Full Notification Object:",
// //       JSON.stringify(notification, null, 2),
// //     );

// //     if (!notification) {
// //       console.log("❌ Notification is null/undefined");
// //       return;
// //     }

// //     console.log(
// //       "📦 Notification ID:",
// //       notification.notificationId || notification.id,
// //     );
// //     console.log("📌 Title:", notification.title);
// //     console.log("📝 Body:", notification.body);
// //     console.log(
// //       "🔗 Additional Data:",
// //       JSON.stringify(notification.additionalData || {}, null, 2),
// //     );

// //     if (userTypeRef.current === "customer") {
// //       console.log("[Notification] Ignored for customer user");
// //       return;
// //     }

// //     const additionalData = notification?.additionalData ?? {};
// //     const pageName = additionalData?.page;

// //     console.log("📍 Page Name from notification:", pageName);

// //     if (pageName !== "asap-job-list") {
// //       console.log(`⚠️ Wrong page name: ${pageName}. Expected "asap-job-list"`);
// //       return;
// //     }

// //     const rosterWrapper = additionalData?.roster ?? {};
// //     const rawRoster = rosterWrapper?.roster ?? {};

// //     console.log("👤 Raw Roster Data:", JSON.stringify(rawRoster, null, 2));
// //     console.log("🆔 Roster ID:", rawRoster?.id);

// //     if (!rawRoster?.id) {
// //       console.log("❌ No roster ID found in notification");
// //       return;
// //     }

// //     const notificationJob = {
// //       additionalData: {
// //         roster: {
// //           roster: { ...rawRoster },
// //           distance: rosterWrapper.distance ?? null,
// //         },
// //       },
// //       roster: { roster: { ...rawRoster } },
// //       distance: rosterWrapper.distance ?? null,
// //     };

// //     console.log(
// //       "✅ Final notificationJob prepared for storage:",
// //       JSON.stringify(notificationJob, null, 2),
// //     );

// //     try {
// //       await AsyncStorage.setItem(
// //         PENDING_ASAP_NOTIFICATION_KEY,
// //         JSON.stringify(notificationJob),
// //       );
// //       console.log("💾 Notification successfully saved to AsyncStorage");
// //     } catch (e) {
// //       console.error("❌ Failed to save notification to AsyncStorage:", e);
// //       return;
// //     }

// //     console.log("🚀 Calling flushPendingNotification...");
// //     flushPendingNotification();
// //   };

// //   // Show Splash Screen
// //   if (isSplashVisible) {
// //     return <SplashScreen />;
// //   }

// //   // Main App
// //   return (
// //     <GestureHandlerRootView style={{ flex: 1 }}>
// //       <StatusBar barStyle="dark-content" backgroundColor="#fff" />
// //       <StripeProvider
// //         publishableKey={STRIPE_PUBLISHABLE_KEY}
// //         merchantIdentifier="merchant.identifier"
// //         urlScheme="your-url-scheme"
// //       >
// //         <NavigationContainer
// //           ref={(ref) => {
// //             navigationRef = ref;
// //           }}
// //           onReady={() => {
// //             flushPendingNotification();
// //           }}
// //         >
// //           <AppNavigator />
// //         </NavigationContainer>
// //       </StripeProvider>

// //       <CallOverlay />
// //       <Toast />
// //     </GestureHandlerRootView>
// //   );
// // }

// // const styles = StyleSheet.create({});

// import React, { useEffect, useRef, useState, useCallback } from "react";
// import {
//   StyleSheet,
//   StatusBar,
//   Platform,
//   AppState,
//   AppStateStatus,
// } from "react-native";
// import { GestureHandlerRootView } from "react-native-gesture-handler";
// import {
//   NavigationContainer,
//   NavigationContainerRef,
// } from "@react-navigation/native";
// import Toast from "react-native-toast-message";
// import { LogLevel, OneSignal } from "react-native-onesignal";
// import AsyncStorage from "@react-native-async-storage/async-storage";
// import { StripeProvider } from "@stripe/stripe-react-native";

// import AppNavigator from "./navigation/AppNavigator";
// import CallOverlay from "./screens/CallOverlay";
// import { useEchoCallListener } from "./useCallManagerRN";
// import SplashScreen from "./screens/SplashScreen";

// // Shared constant - Keep in sync with StaffShifts.tsx
// export const PENDING_ASAP_NOTIFICATION_KEY = "@pending_asap_notification";

// const ONESIGNAL_APP_ID = "79041c59-5506-4e56-9de4-8a6619f85e1d";
// const TARGET_ROUTE_NAME = "StaffShifts";
// const MAIN_TABS_ROUTE_NAME = "MainTabs";

// export let navigationRef: NavigationContainerRef<any> | null = null;

// export default function App() {
//   const STRIPE_PUBLISHABLE_KEY =
//     "pk_test_51TBYBwDb535HMVUZHtQiPJGDYYZex0gIGvFWtuKR9FRage5WxqqzkLDvKBUpq4MfPkWhgDDM7z3WZrURpwWFBkbo005rxvV6q9";

//   const [isSplashVisible, setIsSplashVisible] = useState(true);

//   useEchoCallListener();

//   const userTypeRef = useRef<string | null>(null);
//   const clickHandlerRef = useRef<any>(null);
//   const foregroundHandlerRef = useRef<any>(null);
//   const flushInFlightRef = useRef(false);

//   // Hide splash screen
//   useEffect(() => {
//     const hideSplashTimer = setTimeout(() => {
//       setIsSplashVisible(false);
//     }, 2200);
//     return () => clearTimeout(hideSplashTimer);
//   }, []);

//   // Load user type
//   useEffect(() => {
//     const loadUserTypeAndRequestPermission = async () => {
//       try {
//         const stored = await AsyncStorage.getItem("@user_type");
//         userTypeRef.current = stored;
//         if (stored === "staff" || stored === "contractor") {
//           // requestBackgroundLocationPermission();
//         }
//       } catch (err) {
//         console.warn("Error loading user type:", err);
//       }
//     };
//     loadUserTypeAndRequestPermission();
//   }, []);

//   // ─── flushPendingNotification ────────────────────────────────────────────
//   const flushPendingNotification = useCallback(async () => {
//     if (flushInFlightRef.current) {
//       console.log("⏳ flushPendingNotification already in progress");
//       return;
//     }

//     flushInFlightRef.current = true;
//     console.log("🔄 Starting flushPendingNotification...");

//     try {
//       const pending = await AsyncStorage.getItem(PENDING_ASAP_NOTIFICATION_KEY);
//       console.log("📥 Pending in storage:", pending ? "FOUND" : "NOT FOUND");

//       if (!pending) {
//         flushInFlightRef.current = false;
//         return;
//       }

//       if (navigationRef?.isReady()) {
//         console.log("🧭 Navigating to StaffShifts for pending notification");
//         navigationRef.navigate(MAIN_TABS_ROUTE_NAME, {
//           screen: TARGET_ROUTE_NAME,
//         });

//         // Extra retry after navigation settles
//         setTimeout(() => {
//           console.log("🔁 Retry flush after navigation");
//           // We don't remove the key here - StaffShifts handles it
//         }, 1200);
//       } else {
//         console.log("⚠️ Navigation ref not ready yet");
//       }
//     } catch (e) {
//       console.error("❌ flushPendingNotification error:", e);
//     } finally {
//       flushInFlightRef.current = false;
//     }
//   }, []);

//   // OneSignal Setup
//   useEffect(() => {
//     const initOneSignal = async () => {
//       OneSignal.Debug.setLogLevel(LogLevel.None);
//       OneSignal.initialize(ONESIGNAL_APP_ID);
//       OneSignal.Notifications.requestPermission(true);

//       const handleClick = (event: any) => {
//         const notif = event?.notification ?? null;
//         if (notif) handleNotificationOpen(notif);
//       };
//       clickHandlerRef.current = handleClick;
//       OneSignal.Notifications.addEventListener("click", handleClick);

//       const handleForeground = (event: any) => {
//         if (userTypeRef.current === "customer") {
//           event.preventDefault();
//           return;
//         }
//         const notif = event?.getNotification?.();
//         notif?.display();
//       };
//       foregroundHandlerRef.current = handleForeground;
//       OneSignal.Notifications.addEventListener(
//         "foregroundWillDisplay",
//         handleForeground,
//       );
//     };

//     initOneSignal();

//     return () => {
//       if (clickHandlerRef.current) {
//         OneSignal.Notifications.removeEventListener(
//           "click",
//           clickHandlerRef.current,
//         );
//       }
//       if (foregroundHandlerRef.current) {
//         OneSignal.Notifications.removeEventListener(
//           "foregroundWillDisplay",
//           foregroundHandlerRef.current,
//         );
//       }
//     };
//   }, []);

//   // AppState listener + boot flush
//   useEffect(() => {
//     const sub = AppState.addEventListener("change", (state: AppStateStatus) => {
//       if (state === "active") {
//         flushPendingNotification();
//       }
//     });

//     const bootTimer = setTimeout(() => {
//       flushPendingNotification();
//     }, 800);

//     return () => {
//       sub.remove();
//       clearTimeout(bootTimer);
//     };
//   }, [flushPendingNotification]);

//   // ─── Notification open handler ───
//   const handleNotificationOpen = async (notification: any) => {
//     console.log(
//       "🔴 [NOTIFICATION RECEIVED] Full Notification Object:",
//       JSON.stringify(notification, null, 2),
//     );

//     if (!notification) return;

//     if (userTypeRef.current === "customer") {
//       console.log("[Notification] Ignored for customer user");
//       return;
//     }

//     const additionalData = notification?.additionalData ?? {};
//     const pageName = additionalData?.page;

//     if (pageName !== "asap-job-list") {
//       console.log(`⚠️ Wrong page name: ${pageName}`);
//       return;
//     }

//     const rosterWrapper = additionalData?.roster ?? {};
//     const rawRoster = rosterWrapper?.roster ?? {};

//     if (!rawRoster?.id) {
//       console.log("❌ No roster ID found in notification");
//       return;
//     }

//     const notificationJob = {
//       additionalData: {
//         roster: {
//           roster: { ...rawRoster },
//           distance: rosterWrapper.distance ?? null,
//         },
//       },
//       roster: { roster: { ...rawRoster } },
//       distance: rosterWrapper.distance ?? null,
//     };

//     try {
//       await AsyncStorage.setItem(
//         PENDING_ASAP_NOTIFICATION_KEY,
//         JSON.stringify(notificationJob),
//       );
//       console.log("💾 Notification saved to AsyncStorage");
//     } catch (e) {
//       console.error("❌ Failed to save notification to AsyncStorage:", e);
//       return;
//     }

//     flushPendingNotification();
//   };

//   if (isSplashVisible) {
//     return <SplashScreen />;
//   }

//   return (
//     <GestureHandlerRootView style={{ flex: 1 }}>
//       <StatusBar barStyle="dark-content" backgroundColor="#fff" />
//       <StripeProvider
//         publishableKey={STRIPE_PUBLISHABLE_KEY}
//         merchantIdentifier="merchant.identifier"
//         urlScheme="your-url-scheme"
//       >
//         <NavigationContainer
//           ref={(ref) => {
//             navigationRef = ref;
//           }}
//           onReady={() => {
//             console.log("Navigation Ready → Checking pending notification");
//             flushPendingNotification();
//           }}
//         >
//           <AppNavigator />
//         </NavigationContainer>
//       </StripeProvider>

//       <CallOverlay />
//       <Toast />
//     </GestureHandlerRootView>
//   );
// }

// const styles = StyleSheet.create({});

import React, { useEffect, useRef, useState, useCallback } from "react";
import { StyleSheet, StatusBar, AppState, AppStateStatus } from "react-native";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import {
  NavigationContainer,
  NavigationContainerRef,
} from "@react-navigation/native";
import Toast from "react-native-toast-message";
import { LogLevel, OneSignal } from "react-native-onesignal";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { StripeProvider } from "@stripe/stripe-react-native";

import AppNavigator from "./navigation/AppNavigator";
import CallOverlay from "./screens/CallOverlay";
import { useEchoCallListener } from "./useCallManagerRN";
import SplashScreen from "./screens/SplashScreen";

export const PENDING_ASAP_NOTIFICATION_KEY = "@pending_asap_notification";

const ONESIGNAL_APP_ID = "79041c59-5506-4e56-9de4-8a6619f85e1d";
const TARGET_ROUTE_NAME = "StaffShifts";
const MAIN_TABS_ROUTE_NAME = "MainTabs";

export let navigationRef: NavigationContainerRef<any> | null = null;

export default function App() {
  const STRIPE_PUBLISHABLE_KEY =
    "pk_test_51TBYBwDb535HMVUZHtQiPJGDYYZex0gIGvFWtuKR9FRage5WxqqzkLDvKBUpq4MfPkWhgDDM7z3WZrURpwWFBkbo005rxvV6q9";

  const [isSplashVisible, setIsSplashVisible] = useState(true);
  const flushInFlightRef = useRef(false);
  const userTypeRef = useRef<string | null>(null);

  useEchoCallListener();

  // Hide splash
  useEffect(() => {
    const timer = setTimeout(() => setIsSplashVisible(false), 2200);
    return () => clearTimeout(timer);
  }, []);

  // Load user type
  useEffect(() => {
    const load = async () => {
      try {
        const stored = await AsyncStorage.getItem("@user_type");
        userTypeRef.current = stored;
      } catch (err) {
        console.warn("Error loading user type:", err);
      }
    };
    load();
  }, []);

  // NOTE: this function only NAVIGATES to the screen that owns the pending
  // notification — it deliberately does NOT read-then-remove the
  // AsyncStorage key itself. StaffShifts.checkPendingNotification is the
  // single, module-lock-protected consumer of that key (see StaffShifts.tsx
  // — globalIsCheckingPending). If this function also removed the key here,
  // there'd be two different places racing to consume the same payload,
  // which is exactly the kind of race that caused notifications to
  // sometimes open a second, empty bottom sheet.
  const flushPendingNotification = useCallback(async () => {
    if (flushInFlightRef.current) return;
    flushInFlightRef.current = true;

    try {
      const pending = await AsyncStorage.getItem(
        PENDING_ASAP_NOTIFICATION_KEY,
      );
      if (!pending) return;

      console.log("🧭 Navigating to StaffShifts for pending notification");

      navigationRef?.navigate(MAIN_TABS_ROUTE_NAME, {
        screen: TARGET_ROUTE_NAME,
      });
    } catch (e) {
      console.error("flush error", e);
    } finally {
      flushInFlightRef.current = false;
    }
  }, []);

  // ─── Handle Notification ───────────────────────────────────────
  const handleNotificationOpen = async (notification: any) => {
    console.log(
      "🔴 [NOTIFICATION RECEIVED]",
      JSON.stringify(notification, null, 2),
    );

    if (userTypeRef.current === "customer" || !notification) return;

    const additionalData = notification?.additionalData ?? {};
    if (additionalData?.page !== "asap-job-list") return;

    const rawRoster = additionalData?.roster?.roster ?? {};
    if (!rawRoster?.id) return;

    const notificationJob = {
      additionalData: { roster: { roster: { ...rawRoster } } },
      roster: { roster: { ...rawRoster } },
    };

    try {
      await AsyncStorage.setItem(
        PENDING_ASAP_NOTIFICATION_KEY,
        JSON.stringify(notificationJob),
      );
      console.log("💾 Notification saved to storage");
      flushPendingNotification();
    } catch (e) {
      console.error("Failed to save notification", e);
    }
  };

  // OneSignal Setup
  useEffect(() => {
    OneSignal.Debug.setLogLevel(LogLevel.None);
    OneSignal.initialize(ONESIGNAL_APP_ID);
    OneSignal.Notifications.requestPermission(true);

    const clickHandler = (event: any) =>
      handleNotificationOpen(event?.notification);
    OneSignal.Notifications.addEventListener("click", clickHandler);

    const foregroundHandler = (event: any) => {
      if (userTypeRef.current !== "customer")
        event?.getNotification?.()?.display?.();
    };
    OneSignal.Notifications.addEventListener(
      "foregroundWillDisplay",
      foregroundHandler,
    );

    return () => {
      OneSignal.Notifications.removeEventListener("click", clickHandler);
      OneSignal.Notifications.removeEventListener(
        "foregroundWillDisplay",
        foregroundHandler,
      );
    };
  }, []);

  // AppState + Boot
  useEffect(() => {
    const sub = AppState.addEventListener("change", (state: AppStateStatus) => {
      if (state === "active") flushPendingNotification();
    });

    const bootTimer = setTimeout(flushPendingNotification, 800);

    return () => {
      sub.remove();
      clearTimeout(bootTimer);
    };
  }, [flushPendingNotification]);

  if (isSplashVisible) return <SplashScreen />;

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <StatusBar barStyle="dark-content" backgroundColor="#fff" />
      <StripeProvider publishableKey={STRIPE_PUBLISHABLE_KEY}>
        <NavigationContainer
          ref={(ref) => {
            navigationRef = ref;
          }}
          onReady={() => {
            console.log("Navigation Ready");
            flushPendingNotification();
          }}
        >
          <AppNavigator />
        </NavigationContainer>
      </StripeProvider>

      <CallOverlay />
      <Toast />
    </GestureHandlerRootView>
  );
}